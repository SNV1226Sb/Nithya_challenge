##implement a class bank account
class BankAccount:
def_init_(self,account_number,account_holder_name,initial_balance=0.0
def_init_('self,account_number,account_holder_name,initial_balance'=0.0)
self_account_number=account_number
self_account_holder_name=self_account_holder_name
self_account_balance_=initial_balance
def deposit(self,amount):
     if amount>0:
       self_account_balance+=amount
       print("deposited ${}.new balance:${}".format (amount,self_account_balance))
     else:
       print("invalid deposit amount.please deposit a positive amount.")
       def withdraw(self,amount):
         if amount>0 and amount<=self._account_balance :
           self._account_balance-=amount
           print("withdraw ${}.new balance:${}".format (amount,self._account_balance))
         else:
           print("invalid withdrawl amount or insufficient balance.")
           def display_balance(self):
             print("account balance)for {} (account #{}):${}".format(self_account_holder_name,
self._account_number,
self._account_balance))
account=bankaccount(account_number="123456789", account_holder_name="Elango",initial_balance=5000.0)
account.display_balance()
account.deposit(500.0)
account.withdraw(200.0)
account.display_balance()
account.withdraw(20000.0)
account.display_balance()

##  class player 
def play(self):
               print("the player is playing cricket")
               class batsman(player):
                 def play(self):
                   print("the batsman is batting")
                   class bowler(player):
                     def play(self):
                       print("the bowler is bowling")
                       batsman.play()
                       bowler.play()
                   
                      
                                                                     
                                                                     